/* 1. expressモジュールをロードし、インスタンス化してappに代入。*/
const express = require("express");
const app = express();
const fs = require('fs');

/* 2. listen()メソッドを実行して3000番ポートで待ち受け。*/
var server = app.listen(3000, function(){
    console.log("Node.js is listening to PORT:" + server.address().port);
});

/* 3. 以後、アプリケーション固有の処理 */
//http://localhost:3000/api/data.json
app.get("/api/data.json", function(req, res, next){
    const jsonObject = JSON.parse(fs.readFileSync('./data.json', 'utf8'));
    res.json(jsonObject);        
});

app.post("/api/data.json", function(req, res, next){
     // リクエストボディを出力
     console.log(req.body);  
    // 書き込み
    fs.writeFile('./data.json', req.body, (err) => {
        if (err) throw err;
        console.log('正常に書き込みが完了しました');       
    });
    res.send('POST request to the homepage');
});

